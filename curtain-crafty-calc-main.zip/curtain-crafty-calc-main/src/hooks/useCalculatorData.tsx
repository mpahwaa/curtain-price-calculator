import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Fabric, CurtainType, Addon } from '@/types/database';

export function useFabrics() {
  return useQuery({
    queryKey: ['fabrics'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('fabrics')
        .select('*')
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      return data as Fabric[];
    },
  });
}

export function useCurtainTypes() {
  return useQuery({
    queryKey: ['curtain_types'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('curtain_types')
        .select('*')
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      return data as CurtainType[];
    },
  });
}

export function useAddons() {
  return useQuery({
    queryKey: ['addons'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('addons')
        .select('*')
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      return data as Addon[];
    },
  });
}
