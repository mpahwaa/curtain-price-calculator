export interface Fabric {
  id: string;
  name: string;
  rate_per_meter: number;
  description: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface CurtainType {
  id: string;
  name: string;
  stitching_charge: number;
  description: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Addon {
  id: string;
  name: string;
  price: number;
  description: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string | null;
  email: string | null;
  address: string | null;
  created_at: string;
  updated_at: string;
}

export interface Quote {
  id: string;
  quote_number: string;
  customer_id: string | null;
  height: number;
  fabric_id: string | null;
  curtain_type_id: string | null;
  quantity: number;
  fabric_meters: number;
  fabric_cost: number;
  stitching_cost: number;
  addons_cost: number;
  total_amount: number;
  selected_addons: string[];
  notes: string | null;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface Profile {
  id: string;
  email: string | null;
  full_name: string | null;
  is_admin: boolean;
  created_at: string;
  updated_at: string;
}

export interface PriceBreakdown {
  height: number;
  fabricMeters: number;
  fabricRate: number;
  fabricCost: number;
  stitchingCharge: number;
  addonsCost: number;
  subtotal: number;
  quantity: number;
  grandTotal: number;
}

export interface CurtainMeasurement {
  height: number;
  unit: 'feet' | 'meters' | 'inches';
  quantity: number;
  fabricMeters: number;
  fabricCost: number;
  subtotal: number;
}

export interface MultiPriceBreakdown {
  measurements: CurtainMeasurement[];
  fabricRate: number;
  stitchingChargePerCurtain: number;
  totalStitchingCharge: number;
  addonsPerCurtain: number;
  totalAddonsCost: number;
  totalCurtains: number;
  totalFabricCost: number;
  totalFabricMeters: number;
  grandTotal: number;
}

// New types for dual fabric support
export interface FabricSection {
  fabricName: string;
  ratePerMeter: number;
  measurements: CurtainMeasurement[];
  totalFabricMeters: number;
  totalFabricCost: number;
  totalCurtains: number;
  subtotal: number;
}

export interface DualFabricPriceBreakdown {
  fabric1: FabricSection;
  fabric2: FabricSection;
  stitchingChargePerCurtain: number;
  totalStitchingCharge: number;
  addonsPerCurtain: number;
  totalAddonsCost: number;
  totalCurtains: number;
  totalFabricMeters: number;
  totalFabricCost: number;
  grandTotal: number;
}
