import { PriceBreakdown, CurtainMeasurement, MultiPriceBreakdown, FabricSection, DualFabricPriceBreakdown } from "@/types/database";

// Conversion constants
const FEET_TO_METERS = 0.3048;
const INCHES_TO_METERS = 0.0254;
// Hemming allowance in meters
const HEMMING_ALLOWANCE = 0.30;

export type MeasurementUnit = 'feet' | 'meters' | 'inches';

export function convertToMeters(height: number, unit: MeasurementUnit): number {
  switch (unit) {
    case 'feet':
      return height * FEET_TO_METERS;
    case 'inches':
      return height * INCHES_TO_METERS;
    case 'meters':
      return height;
  }
}

export function convertHeightToFabricMeters(height: number, unit: MeasurementUnit): number {
  return convertToMeters(height, unit) + HEMMING_ALLOWANCE;
}

// Legacy function for backwards compatibility
export function convertHeightToMeters(heightFeet: number): number {
  return (heightFeet * FEET_TO_METERS) + HEMMING_ALLOWANCE;
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
  }).format(amount);
}

export function calculatePrice(
  height: number,
  fabricRate: number,
  stitchingCharge: number,
  addonsCost: number,
  quantity: number
): PriceBreakdown {
  const fabricMeters = convertHeightToMeters(height);
  const fabricCost = fabricMeters * fabricRate;
  const subtotal = fabricCost + stitchingCharge + addonsCost;
  const grandTotal = subtotal * quantity;

  return {
    height,
    fabricMeters,
    fabricRate,
    fabricCost,
    stitchingCharge,
    addonsCost,
    subtotal,
    quantity,
    grandTotal,
  };
}

export function calculateMultiPrice(
  measurements: { height: number; unit: MeasurementUnit; quantity: number }[],
  fabricRate: number,
  stitchingChargePerCurtain: number,
  addonsPerCurtain: number
): MultiPriceBreakdown {
  const calculatedMeasurements: CurtainMeasurement[] = measurements
    .filter(m => m.height > 0 && m.quantity > 0)
    .map(m => {
      const fabricMeters = convertHeightToFabricMeters(m.height, m.unit);
      const fabricCost = fabricMeters * fabricRate;
      return {
        height: m.height,
        unit: m.unit,
        quantity: m.quantity,
        fabricMeters,
        fabricCost,
        subtotal: (fabricCost + stitchingChargePerCurtain + addonsPerCurtain) * m.quantity,
      };
    });

  const totalCurtains = calculatedMeasurements.reduce((sum, m) => sum + m.quantity, 0);
  const totalFabricCost = calculatedMeasurements.reduce((sum, m) => sum + (m.fabricCost * m.quantity), 0);
  const totalFabricMeters = calculatedMeasurements.reduce((sum, m) => sum + (m.fabricMeters * m.quantity), 0);
  const totalStitchingCharge = stitchingChargePerCurtain * totalCurtains;
  const totalAddonsCost = addonsPerCurtain * totalCurtains;
  const grandTotal = totalFabricCost + totalStitchingCharge + totalAddonsCost;

  return {
    measurements: calculatedMeasurements,
    fabricRate,
    stitchingChargePerCurtain,
    totalStitchingCharge,
    addonsPerCurtain,
    totalAddonsCost,
    totalCurtains,
    totalFabricCost,
    totalFabricMeters,
    grandTotal,
  };
}

export function calculateFabricSection(
  measurements: { height: number; unit: MeasurementUnit; quantity: number }[],
  fabricName: string,
  ratePerMeter: number,
  stitchingChargePerCurtain: number,
  addonsPerCurtain: number
): FabricSection {
  const calculatedMeasurements: CurtainMeasurement[] = measurements
    .filter(m => m.height > 0 && m.quantity > 0)
    .map(m => {
      const fabricMeters = convertHeightToFabricMeters(m.height, m.unit);
      const fabricCost = fabricMeters * ratePerMeter;
      return {
        height: m.height,
        unit: m.unit,
        quantity: m.quantity,
        fabricMeters,
        fabricCost,
        subtotal: (fabricCost + stitchingChargePerCurtain + addonsPerCurtain) * m.quantity,
      };
    });

  const totalCurtains = calculatedMeasurements.reduce((sum, m) => sum + m.quantity, 0);
  const totalFabricCost = calculatedMeasurements.reduce((sum, m) => sum + (m.fabricCost * m.quantity), 0);
  const totalFabricMeters = calculatedMeasurements.reduce((sum, m) => sum + (m.fabricMeters * m.quantity), 0);
  const subtotal = calculatedMeasurements.reduce((sum, m) => sum + m.subtotal, 0);

  return {
    fabricName,
    ratePerMeter,
    measurements: calculatedMeasurements,
    totalFabricMeters,
    totalFabricCost,
    totalCurtains,
    subtotal,
  };
}

export function calculateDualFabricPrice(
  fabric1Measurements: { height: number; unit: MeasurementUnit; quantity: number }[],
  fabric1Name: string,
  fabric1Rate: number,
  fabric2Measurements: { height: number; unit: MeasurementUnit; quantity: number }[],
  fabric2Name: string,
  fabric2Rate: number,
  stitchingChargePerCurtain: number,
  addonsPerCurtain: number
): DualFabricPriceBreakdown {
  const fabric1 = calculateFabricSection(fabric1Measurements, fabric1Name, fabric1Rate, stitchingChargePerCurtain, addonsPerCurtain);
  const fabric2 = calculateFabricSection(fabric2Measurements, fabric2Name, fabric2Rate, stitchingChargePerCurtain, addonsPerCurtain);

  const totalCurtains = fabric1.totalCurtains + fabric2.totalCurtains;
  const totalFabricMeters = fabric1.totalFabricMeters + fabric2.totalFabricMeters;
  const totalFabricCost = fabric1.totalFabricCost + fabric2.totalFabricCost;
  const totalStitchingCharge = stitchingChargePerCurtain * totalCurtains;
  const totalAddonsCost = addonsPerCurtain * totalCurtains;
  const grandTotal = totalFabricCost + totalStitchingCharge + totalAddonsCost;

  return {
    fabric1,
    fabric2,
    stitchingChargePerCurtain,
    totalStitchingCharge,
    addonsPerCurtain,
    totalAddonsCost,
    totalCurtains,
    totalFabricMeters,
    totalFabricCost,
    grandTotal,
  };
}

export function generateQuoteNumber(): string {
  const date = new Date();
  const year = date.getFullYear().toString().slice(-2);
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  return `QT${year}${month}${random}`;
}
