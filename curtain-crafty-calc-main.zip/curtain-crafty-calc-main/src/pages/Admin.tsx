import { useAuth } from '@/hooks/useAuth';
import { Navigate, Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Home, LogOut, Package, Scissors, Plus, FileText } from 'lucide-react';

export default function Admin() {
  const { user, profile, isAdmin, isLoading, signOut } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-serif font-semibold text-primary">Admin Panel</h1>
            <p className="text-sm text-muted-foreground">
              Welcome, {profile?.full_name || user.email}
              {isAdmin && <span className="ml-2 text-accent">(Admin)</span>}
            </p>
          </div>
          <div className="flex gap-2">
            <Link to="/">
              <Button variant="outline" size="sm">
                <Home className="h-4 w-4 mr-2" />
                Calculator
              </Button>
            </Link>
            <Button variant="outline" size="sm" onClick={signOut}>
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {!isAdmin ? (
          <Card className="max-w-md mx-auto">
            <CardContent className="pt-6 text-center">
              <p className="text-muted-foreground mb-4">
                Your account doesn't have admin access yet. Please contact the administrator.
              </p>
              <Button variant="outline" onClick={signOut}>Sign Out</Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="shadow-soft hover:shadow-elevated transition-shadow cursor-pointer">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-serif">
                  <Package className="h-5 w-5 text-accent" />
                  Fabrics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Manage fabric types and rates</p>
              </CardContent>
            </Card>

            <Card className="shadow-soft hover:shadow-elevated transition-shadow cursor-pointer">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-serif">
                  <Scissors className="h-5 w-5 text-accent" />
                  Curtain Styles
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Manage styles, multipliers & stitching</p>
              </CardContent>
            </Card>

            <Card className="shadow-soft hover:shadow-elevated transition-shadow cursor-pointer">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-serif">
                  <Plus className="h-5 w-5 text-accent" />
                  Add-ons
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Manage add-on items & pricing</p>
              </CardContent>
            </Card>

            <Card className="shadow-soft hover:shadow-elevated transition-shadow cursor-pointer">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-serif">
                  <FileText className="h-5 w-5 text-accent" />
                  Quotes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">View all generated quotes</p>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}
