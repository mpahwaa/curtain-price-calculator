import { useState } from 'react';
import CalculatorForm from '@/components/calculator/CalculatorForm';
import QuoteGenerator from '@/components/calculator/QuoteGenerator';
import QuoteHistory from '@/components/QuoteHistory';
import { Link } from 'react-router-dom';
import { Settings, History } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Index = () => {
  const [showHistory, setShowHistory] = useState(false);
  const [quoteData, setQuoteData] = useState<any>(null);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl md:text-3xl font-serif font-semibold text-primary">
              Curtain Calculator
            </h1>
            <p className="text-sm text-muted-foreground">Get instant price estimates</p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowHistory(true)}
              className="gap-2"
            >
              <History className="h-4 w-4" />
              History
            </Button>
            <Link 
              to="/admin" 
              className="p-2 rounded-lg hover:bg-secondary transition-colors"
              title="Admin Panel"
            >
              <Settings className="h-5 w-5 text-muted-foreground" />
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-lg">
        {showHistory ? (
          <QuoteHistory onClose={() => setShowHistory(false)} />
        ) : quoteData ? (
          <QuoteGenerator 
            data={quoteData} 
            onBack={() => setQuoteData(null)} 
          />
        ) : (
          <CalculatorForm onGenerateQuote={setQuoteData} />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border py-6 mt-12">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Curtain Calculator. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
