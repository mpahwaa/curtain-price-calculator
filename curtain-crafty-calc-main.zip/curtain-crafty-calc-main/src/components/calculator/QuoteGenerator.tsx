import { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { supabase } from '@/integrations/supabase/client';
import { generateQuoteNumber, formatCurrency, MeasurementUnit } from '@/lib/calculations';
import { CurtainType, Addon, DualFabricPriceBreakdown } from '@/types/database';
import { User, FileText, Download } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import jsPDF from 'jspdf';

interface QuoteGeneratorProps {
  data: {
    fabric1: { name: string; rate: number; measurements: { height: number; unit: MeasurementUnit; quantity: number }[] };
    fabric2: { name: string; rate: number; measurements: { height: number; unit: MeasurementUnit; quantity: number }[] };
    curtainType: CurtainType;
    selectedAddons: Addon[];
    priceBreakdown: DualFabricPriceBreakdown;
  };
  onBack: () => void;
}

export default function QuoteGenerator({ data, onBack }: QuoteGeneratorProps) {
  const { toast } = useToast();
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [notes, setNotes] = useState('');
  const [isExporting, setIsExporting] = useState(false);
  const [errors, setErrors] = useState<{ name?: string; phone?: string }>({});

  const validateForm = () => {
    const newErrors: { name?: string; phone?: string } = {};
    
    if (!customerName.trim()) {
      newErrors.name = 'Name is required';
    }
    if (!customerPhone.trim()) {
      newErrors.phone = 'Mobile number is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleExportPDF = async () => {
    if (!validateForm()) {
      toast({
        title: 'Required Fields',
        description: 'Please enter customer name and mobile number.',
        variant: 'destructive',
      });
      return;
    }

    setIsExporting(true);

    try {
      // Create customer
      const { data: customerData, error: customerError } = await supabase
        .from('customers')
        .insert({
          name: customerName.trim(),
          phone: customerPhone.trim(),
          email: customerEmail.trim() || null,
        })
        .select()
        .single();

      if (customerError) throw customerError;

      // Generate quote number
      const newQuoteNumber = generateQuoteNumber();

      // Use first measurement height for the quote
      const primaryHeight = data.fabric1.measurements[0]?.height || data.fabric2.measurements[0]?.height || 0;
      const primaryUnit = data.fabric1.measurements[0]?.unit || data.fabric2.measurements[0]?.unit || 'feet';

      // Create quote in database
      const { error: quoteError } = await supabase
        .from('quotes')
        .insert({
          quote_number: newQuoteNumber,
          customer_id: customerData.id,
          width: 48,
          height: primaryHeight,
          unit: primaryUnit,
          fabric_id: null,
          curtain_type_id: data.curtainType.id,
          quantity: data.priceBreakdown.totalCurtains,
          fabric_meters: data.priceBreakdown.totalFabricMeters,
          fabric_cost: data.priceBreakdown.totalFabricCost,
          stitching_cost: data.priceBreakdown.totalStitchingCharge,
          addons_cost: data.priceBreakdown.totalAddonsCost,
          total_amount: data.priceBreakdown.grandTotal,
          selected_addons: data.selectedAddons.map(a => a.id),
          notes: notes.trim() || null,
          status: 'pending',
        });

      if (quoteError) throw quoteError;

      // Generate PDF
      const doc = new jsPDF();
      let y = 20;

      doc.setFontSize(20);
      doc.text('Curtain Quote', 105, y, { align: 'center' });
      y += 10;
      
      doc.setFontSize(12);
      doc.text(`Quote #${newQuoteNumber}`, 105, y, { align: 'center' });
      y += 8;
      doc.text(`Date: ${new Date().toLocaleDateString('en-IN')}`, 105, y, { align: 'center' });
      y += 15;

      // Customer Details
      doc.setFontSize(14);
      doc.text('Customer Details', 20, y);
      y += 8;
      doc.setFontSize(11);
      doc.text(`Name: ${customerName}`, 20, y);
      y += 6;
      doc.text(`Phone: ${customerPhone}`, 20, y);
      y += 6;
      if (customerEmail) {
        doc.text(`Email: ${customerEmail}`, 20, y);
        y += 6;
      }
      y += 8;

      // Fabric 1
      if (data.priceBreakdown.fabric1.totalCurtains > 0) {
        doc.setFontSize(14);
        doc.text(data.priceBreakdown.fabric1.fabricName, 20, y);
        y += 8;
        doc.setFontSize(11);
        doc.text(`Rate: ${formatCurrency(data.priceBreakdown.fabric1.ratePerMeter)}/m`, 20, y);
        y += 6;
        data.priceBreakdown.fabric1.measurements.forEach((m, i) => {
          doc.text(`Curtain ${i + 1}: ${m.height} ${m.unit} → ${m.fabricMeters.toFixed(2)}m × ${m.quantity} = ${formatCurrency(m.subtotal)}`, 20, y);
          y += 6;
        });
        doc.text(`Fabric Required: ${data.priceBreakdown.fabric1.totalFabricMeters.toFixed(2)}m`, 20, y);
        y += 10;
      }

      // Fabric 2
      if (data.priceBreakdown.fabric2.totalCurtains > 0) {
        doc.setFontSize(14);
        doc.text(data.priceBreakdown.fabric2.fabricName, 20, y);
        y += 8;
        doc.setFontSize(11);
        doc.text(`Rate: ${formatCurrency(data.priceBreakdown.fabric2.ratePerMeter)}/m`, 20, y);
        y += 6;
        data.priceBreakdown.fabric2.measurements.forEach((m, i) => {
          doc.text(`Curtain ${i + 1}: ${m.height} ${m.unit} → ${m.fabricMeters.toFixed(2)}m × ${m.quantity} = ${formatCurrency(m.subtotal)}`, 20, y);
          y += 6;
        });
        doc.text(`Fabric Required: ${data.priceBreakdown.fabric2.totalFabricMeters.toFixed(2)}m`, 20, y);
        y += 10;
      }

      // Style
      doc.setFontSize(14);
      doc.text('Curtain Style', 20, y);
      y += 8;
      doc.setFontSize(11);
      doc.text(`Style: ${data.curtainType.name}`, 20, y);
      y += 6;
      doc.text(`Stitching: ${formatCurrency(Number(data.curtainType.stitching_charge))} per curtain`, 20, y);
      y += 10;

      // Add-ons
      if (data.selectedAddons.length > 0) {
        doc.setFontSize(14);
        doc.text('Add-ons (per curtain)', 20, y);
        y += 8;
        doc.setFontSize(11);
        data.selectedAddons.forEach(addon => {
          doc.text(`${addon.name}: ${formatCurrency(Number(addon.price))}`, 20, y);
          y += 6;
        });
        y += 4;
      }

      // Price Breakdown
      doc.setFontSize(14);
      doc.text('Price Breakdown', 20, y);
      y += 8;
      doc.setFontSize(11);
      doc.text(`Total Fabric Required: ${data.priceBreakdown.totalFabricMeters.toFixed(2)} meters`, 20, y);
      y += 6;
      doc.text(`Total Fabric Cost: ${formatCurrency(data.priceBreakdown.totalFabricCost)}`, 20, y);
      y += 6;
      doc.text(`Stitching (${data.priceBreakdown.totalCurtains} curtains): ${formatCurrency(data.priceBreakdown.totalStitchingCharge)}`, 20, y);
      y += 6;
      if (data.priceBreakdown.totalAddonsCost > 0) {
        doc.text(`Add-ons (${data.priceBreakdown.totalCurtains} curtains): ${formatCurrency(data.priceBreakdown.totalAddonsCost)}`, 20, y);
        y += 6;
      }
      y += 4;
      doc.setFontSize(14);
      doc.text(`Grand Total: ${formatCurrency(data.priceBreakdown.grandTotal)}`, 20, y);

      if (notes) {
        y += 12;
        doc.setFontSize(14);
        doc.text('Notes', 20, y);
        y += 8;
        doc.setFontSize(11);
        doc.text(notes, 20, y, { maxWidth: 170 });
      }

      doc.save(`Quote-${newQuoteNumber}.pdf`);

      toast({
        title: 'Quote Exported!',
        description: `Quote ${newQuoteNumber} saved and PDF downloaded.`,
      });

      // Reset form and go back
      onBack();
    } catch (error: any) {
      console.error('Error exporting quote:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to export quote. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsExporting(false);
    }
  };

  const isFormValid = customerName.trim() && customerPhone.trim();

  return (
    <div className="space-y-6 animate-fade-in">
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl font-serif">
            <User className="h-5 w-5 text-accent" />
            Customer Details
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name <span className="text-destructive">*</span></Label>
              <Input
                id="name"
                value={customerName}
                onChange={(e) => {
                  setCustomerName(e.target.value);
                  if (errors.name) setErrors(prev => ({ ...prev, name: undefined }));
                }}
                placeholder="Enter customer name"
                className={errors.name ? 'border-destructive' : ''}
              />
              {errors.name && <p className="text-sm text-destructive">{errors.name}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Mobile Number <span className="text-destructive">*</span></Label>
              <Input
                id="phone"
                type="tel"
                value={customerPhone}
                onChange={(e) => {
                  setCustomerPhone(e.target.value);
                  if (errors.phone) setErrors(prev => ({ ...prev, phone: undefined }));
                }}
                placeholder="Enter mobile number"
                className={errors.phone ? 'border-destructive' : ''}
              />
              {errors.phone && <p className="text-sm text-destructive">{errors.phone}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={customerEmail}
                onChange={(e) => setCustomerEmail(e.target.value)}
                placeholder="Enter email address"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Any special requirements or notes..."
              rows={3}
            />
          </div>
          </div>
        </CardContent>
      </Card>

      {/* Quote Summary */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl font-serif">
            <FileText className="h-5 w-5 text-accent" />
            Quote Summary
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* Fabric 1 summary */}
          {data.priceBreakdown.fabric1.totalCurtains > 0 && (
            <div className="text-sm space-y-1 pb-2 border-b border-border">
              <p className="font-medium">{data.priceBreakdown.fabric1.fabricName}</p>
              <p className="text-muted-foreground">
                {data.priceBreakdown.fabric1.totalCurtains} curtains • {data.priceBreakdown.fabric1.totalFabricMeters.toFixed(2)}m fabric • {formatCurrency(data.priceBreakdown.fabric1.subtotal)}
              </p>
            </div>
          )}
          
          {/* Fabric 2 summary */}
          {data.priceBreakdown.fabric2.totalCurtains > 0 && (
            <div className="text-sm space-y-1 pb-2 border-b border-border">
              <p className="font-medium">{data.priceBreakdown.fabric2.fabricName}</p>
              <p className="text-muted-foreground">
                {data.priceBreakdown.fabric2.totalCurtains} curtains • {data.priceBreakdown.fabric2.totalFabricMeters.toFixed(2)}m fabric • {formatCurrency(data.priceBreakdown.fabric2.subtotal)}
              </p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-2 text-sm">
            <span className="text-muted-foreground">Style:</span>
            <span>{data.curtainType.name}</span>
            <span className="text-muted-foreground">Total Curtains:</span>
            <span>{data.priceBreakdown.totalCurtains}</span>
            <span className="text-muted-foreground">Total Fabric:</span>
            <span>{data.priceBreakdown.totalFabricMeters.toFixed(2)} m</span>
          </div>
          
          <div className="border-t border-border pt-3 flex justify-between items-center">
            <span className="font-semibold">Total</span>
            <span className="text-xl font-bold text-primary">
              {formatCurrency(data.priceBreakdown.grandTotal)}
            </span>
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-4">
        <Button variant="outline" onClick={onBack} className="flex-1">
          Back
        </Button>
        <Button 
          onClick={handleExportPDF} 
          disabled={isExporting || !isFormValid}
          className="flex-1"
        >
          <Download className="h-4 w-4 mr-2" />
          {isExporting ? 'Exporting...' : 'Export PDF'}
        </Button>
      </div>
    </div>
  );
}
