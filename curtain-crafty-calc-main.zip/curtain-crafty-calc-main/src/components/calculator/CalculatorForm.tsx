import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { useCurtainTypes, useAddons } from '@/hooks/useCalculatorData';
import { calculateDualFabricPrice, formatCurrency, convertHeightToFabricMeters, MeasurementUnit } from '@/lib/calculations';
import { CurtainType, Addon, DualFabricPriceBreakdown } from '@/types/database';
import { Ruler, Scissors, Plus, Calculator, ChevronDown } from 'lucide-react';

interface MeasurementRow {
  height: string;
  unit: MeasurementUnit;
  quantity: string;
}

interface FabricSectionState {
  name: string;
  rate: string;
  measurements: MeasurementRow[];
}

interface CalculatorFormProps {
  onGenerateQuote: (data: {
    fabric1: { name: string; rate: number; measurements: { height: number; unit: MeasurementUnit; quantity: number }[] };
    fabric2: { name: string; rate: number; measurements: { height: number; unit: MeasurementUnit; quantity: number }[] };
    curtainType: CurtainType;
    selectedAddons: Addon[];
    priceBreakdown: DualFabricPriceBreakdown;
  }) => void;
}

const createEmptyMeasurements = (): MeasurementRow[] => [
  { height: '', unit: 'feet', quantity: '' },
  { height: '', unit: 'feet', quantity: '' },
  { height: '', unit: 'feet', quantity: '' },
  { height: '', unit: 'feet', quantity: '' },
];

export default function CalculatorForm({ onGenerateQuote }: CalculatorFormProps) {
  const { data: curtainTypes, isLoading: typesLoading } = useCurtainTypes();
  const { data: addons, isLoading: addonsLoading } = useAddons();

  // Fabric 1 state
  const [fabric1, setFabric1] = useState<FabricSectionState>({
    name: '',
    rate: '',
    measurements: createEmptyMeasurements(),
  });

  // Fabric 2 state
  const [fabric2, setFabric2] = useState<FabricSectionState>({
    name: '',
    rate: '',
    measurements: createEmptyMeasurements(),
  });

  const [selectedTypeId, setSelectedTypeId] = useState<string>('');
  const [selectedAddonIds, setSelectedAddonIds] = useState<string[]>([]);
  const [showAddons, setShowAddons] = useState(false);

  const selectedCurtainType = useMemo(() => 
    curtainTypes?.find(t => t.id === selectedTypeId),
    [curtainTypes, selectedTypeId]
  );

  const selectedAddons = useMemo(() => 
    addons?.filter(a => selectedAddonIds.includes(a.id)) ?? [],
    [addons, selectedAddonIds]
  );

  const addonsCost = useMemo(() => 
    selectedAddons.reduce((sum, addon) => sum + Number(addon.price), 0),
    [selectedAddons]
  );

  const getValidMeasurements = (measurements: MeasurementRow[]) => 
    measurements
      .map(m => ({ height: parseFloat(m.height) || 0, unit: m.unit, quantity: parseInt(m.quantity) || 0 }))
      .filter(m => m.height > 0 && m.quantity > 0);

  const fabric1ValidMeasurements = useMemo(() => getValidMeasurements(fabric1.measurements), [fabric1.measurements]);
  const fabric2ValidMeasurements = useMemo(() => getValidMeasurements(fabric2.measurements), [fabric2.measurements]);

  const fabric1Rate = parseFloat(fabric1.rate) || 0;
  const fabric2Rate = parseFloat(fabric2.rate) || 0;

  const priceBreakdown = useMemo(() => {
    const hasFabric1 = fabric1ValidMeasurements.length > 0 && fabric1Rate > 0;
    const hasFabric2 = fabric2ValidMeasurements.length > 0 && fabric2Rate > 0;

    if (!hasFabric1 && !hasFabric2) return null;
    if (!selectedCurtainType) return null;

    return calculateDualFabricPrice(
      fabric1ValidMeasurements,
      fabric1.name || 'Fabric 1',
      fabric1Rate,
      fabric2ValidMeasurements,
      fabric2.name || 'Fabric 2',
      fabric2Rate,
      Number(selectedCurtainType.stitching_charge),
      addonsCost
    );
  }, [fabric1ValidMeasurements, fabric2ValidMeasurements, fabric1.name, fabric2.name, fabric1Rate, fabric2Rate, selectedCurtainType, addonsCost]);

  const updateFabric1Measurement = (index: number, field: keyof MeasurementRow, value: string | MeasurementUnit) => {
    setFabric1(prev => {
      const updated = { ...prev, measurements: [...prev.measurements] };
      updated.measurements[index] = { ...updated.measurements[index], [field]: value };
      return updated;
    });
  };

  const updateFabric2Measurement = (index: number, field: keyof MeasurementRow, value: string | MeasurementUnit) => {
    setFabric2(prev => {
      const updated = { ...prev, measurements: [...prev.measurements] };
      updated.measurements[index] = { ...updated.measurements[index], [field]: value };
      return updated;
    });
  };

  const handleAddonToggle = (addonId: string) => {
    setSelectedAddonIds(prev => 
      prev.includes(addonId) 
        ? prev.filter(id => id !== addonId)
        : [...prev, addonId]
    );
  };

  const handleGenerateQuote = () => {
    if (!priceBreakdown || !selectedCurtainType) return;
    
    onGenerateQuote({
      fabric1: { name: fabric1.name || 'Fabric 1', rate: fabric1Rate, measurements: fabric1ValidMeasurements },
      fabric2: { name: fabric2.name || 'Fabric 2', rate: fabric2Rate, measurements: fabric2ValidMeasurements },
      curtainType: selectedCurtainType,
      selectedAddons,
      priceBreakdown,
    });
  };

  const isLoading = typesLoading || addonsLoading;
  const isValid = priceBreakdown && priceBreakdown.totalCurtains > 0;

  if (isLoading) {
    return (
      <Card className="shadow-elevated animate-fade-in">
        <CardContent className="flex items-center justify-center py-12">
          <div className="text-muted-foreground">Loading calculator...</div>
        </CardContent>
      </Card>
    );
  }

  const renderMeasurementRows = (
    measurements: MeasurementRow[],
    updateMeasurement: (index: number, field: keyof MeasurementRow, value: string | MeasurementUnit) => void,
    fabricRate: number
  ) => (
    <div className="space-y-3">
      <div className="grid grid-cols-12 gap-2 items-end text-xs text-muted-foreground">
        <div className="col-span-1"></div>
        <div className="col-span-3">Height</div>
        <div className="col-span-3">Unit</div>
        <div className="col-span-2">Qty</div>
        <div className="col-span-3">Fabric</div>
      </div>
      
      {measurements.map((row, index) => {
        const heightNum = parseFloat(row.height) || 0;
        const fabricMeters = heightNum > 0 ? convertHeightToFabricMeters(heightNum, row.unit) : 0;
        
        return (
          <div key={index} className="grid grid-cols-12 gap-2 items-center">
            <div className="col-span-1 flex items-center justify-center h-10 text-sm font-medium text-muted-foreground">
              {index + 1}.
            </div>
            <div className="col-span-3">
              <Input
                type="number"
                placeholder="Height"
                value={row.height}
                onChange={(e) => updateMeasurement(index, 'height', e.target.value)}
                step="0.5"
                min="0"
              />
            </div>
            <div className="col-span-3">
              <Select 
                value={row.unit} 
                onValueChange={(value: MeasurementUnit) => updateMeasurement(index, 'unit', value)}
              >
                <SelectTrigger className="h-10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="feet">Feet</SelectItem>
                  <SelectItem value="meters">Meters</SelectItem>
                  <SelectItem value="inches">Inches</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2">
              <Input
                type="number"
                min={1}
                placeholder="Qty"
                value={row.quantity}
                onChange={(e) => updateMeasurement(index, 'quantity', e.target.value)}
              />
            </div>
            <div className="col-span-3 flex items-center h-10 text-sm text-muted-foreground">
              {fabricMeters > 0 && (
                <span>= {fabricMeters.toFixed(2)}m</span>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Fabric 1 Section */}
      <Card className="shadow-soft">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-xl font-serif">
            <div className="h-5 w-5 rounded bg-accent/20 flex items-center justify-center">
              <div className="h-3 w-3 rounded-sm bg-accent" />
            </div>
            Fabric 1
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="fabric1Name">Fabric Name</Label>
              <Input
                id="fabric1Name"
                placeholder="Enter fabric name"
                value={fabric1.name}
                onChange={(e) => setFabric1(prev => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="fabric1Rate">Rate per Meter (₹)</Label>
              <Input
                id="fabric1Rate"
                type="number"
                placeholder="Enter rate"
                value={fabric1.rate}
                onChange={(e) => setFabric1(prev => ({ ...prev, rate: e.target.value }))}
                min="0"
                step="0.01"
              />
            </div>
          </div>
          
          <div className="pt-2">
            <p className="text-xs text-muted-foreground mb-3">
              Formula: (Height → meters) + 0.40m hemming = Fabric required
            </p>
            {renderMeasurementRows(fabric1.measurements, updateFabric1Measurement, fabric1Rate)}
          </div>
        </CardContent>
      </Card>

      {/* Fabric 2 Section */}
      <Card className="shadow-soft">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-xl font-serif">
            <div className="h-5 w-5 rounded bg-primary/20 flex items-center justify-center">
              <div className="h-3 w-3 rounded-sm bg-primary" />
            </div>
            Fabric 2
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="fabric2Name">Fabric Name</Label>
              <Input
                id="fabric2Name"
                placeholder="Enter fabric name"
                value={fabric2.name}
                onChange={(e) => setFabric2(prev => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="fabric2Rate">Rate per Meter (₹)</Label>
              <Input
                id="fabric2Rate"
                type="number"
                placeholder="Enter rate"
                value={fabric2.rate}
                onChange={(e) => setFabric2(prev => ({ ...prev, rate: e.target.value }))}
                min="0"
                step="0.01"
              />
            </div>
          </div>
          
          <div className="pt-2">
            <p className="text-xs text-muted-foreground mb-3">
              Formula: (Height → meters) + 0.40m hemming = Fabric required
            </p>
            {renderMeasurementRows(fabric2.measurements, updateFabric2Measurement, fabric2Rate)}
          </div>
        </CardContent>
      </Card>

      {/* Curtain Style */}
      <Card className="shadow-soft">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-xl font-serif">
            <Scissors className="h-5 w-5 text-accent" />
            Curtain Style
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Select value={selectedTypeId} onValueChange={setSelectedTypeId}>
            <SelectTrigger>
              <SelectValue placeholder="Choose curtain style" />
            </SelectTrigger>
            <SelectContent>
              {curtainTypes?.map((type) => (
                <SelectItem key={type.id} value={type.id}>
                  <div className="flex justify-between items-center w-full gap-4">
                    <span>{type.name}</span>
                    <span className="text-muted-foreground text-sm">
                      ₹{Number(type.stitching_charge)}
                    </span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {selectedCurtainType && (
            <div className="mt-3 p-3 rounded-lg bg-secondary/50 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Stitching charge per curtain:</span>
                <span className="font-medium">{formatCurrency(Number(selectedCurtainType.stitching_charge))}</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add-ons - Collapsible */}
      <Card className="shadow-soft">
        <Collapsible open={showAddons} onOpenChange={setShowAddons}>
          <CollapsibleTrigger asChild>
            <CardHeader className="pb-4 cursor-pointer hover:bg-secondary/30 transition-colors rounded-t-lg">
              <CardTitle className="flex items-center justify-between text-xl font-serif">
                <div className="flex items-center gap-2">
                  <Plus className="h-5 w-5 text-accent" />
                  Additional Options
                </div>
                <ChevronDown className={`h-5 w-5 text-muted-foreground transition-transform ${showAddons ? 'rotate-180' : ''}`} />
              </CardTitle>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent>
              <div className="space-y-3">
                {addons?.map((addon) => (
                  <div
                    key={addon.id}
                    className="flex items-center justify-between p-3 rounded-lg border border-border hover:bg-secondary/30 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <Checkbox
                        id={addon.id}
                        checked={selectedAddonIds.includes(addon.id)}
                        onCheckedChange={() => handleAddonToggle(addon.id)}
                      />
                      <label htmlFor={addon.id} className="cursor-pointer">
                        <div className="font-medium">{addon.name}</div>
                        {addon.description && (
                          <div className="text-sm text-muted-foreground">{addon.description}</div>
                        )}
                      </label>
                    </div>
                    <div className="font-semibold text-primary">
                      {formatCurrency(Number(addon.price))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </CollapsibleContent>
        </Collapsible>
      </Card>

      {/* Price Summary */}
      {priceBreakdown && priceBreakdown.totalCurtains > 0 && (
        <Card className="shadow-elevated border-accent/20 bg-gradient-to-br from-card to-secondary/20">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-xl font-serif">
              <Calculator className="h-5 w-5 text-accent" />
              Price Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Fabric 1 breakdown */}
            {priceBreakdown.fabric1.totalCurtains > 0 && (
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">{priceBreakdown.fabric1.fabricName} (₹{priceBreakdown.fabric1.ratePerMeter}/m)</h4>
                {priceBreakdown.fabric1.measurements.map((m, index) => (
                  <div key={index} className="p-3 rounded-lg bg-secondary/30 text-sm space-y-1">
                    <div className="flex justify-between font-medium">
                      <span>Curtain {index + 1}</span>
                      <span>{formatCurrency(m.subtotal)}</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground text-xs">
                      <span>
                        {m.height} {m.unit} → {m.fabricMeters.toFixed(2)}m × ₹{priceBreakdown.fabric1.ratePerMeter} = {formatCurrency(m.fabricCost)}
                      </span>
                      <span>× {m.quantity}</span>
                    </div>
                  </div>
                ))}
                <div className="flex justify-between text-sm pt-1">
                  <span className="text-muted-foreground">Fabric 1 Subtotal:</span>
                  <span className="font-medium">{formatCurrency(priceBreakdown.fabric1.subtotal)} ({priceBreakdown.fabric1.totalFabricMeters.toFixed(2)}m)</span>
                </div>
              </div>
            )}

            {/* Fabric 2 breakdown */}
            {priceBreakdown.fabric2.totalCurtains > 0 && (
              <div className="space-y-2 pt-2 border-t border-border">
                <h4 className="font-semibold text-sm">{priceBreakdown.fabric2.fabricName} (₹{priceBreakdown.fabric2.ratePerMeter}/m)</h4>
                {priceBreakdown.fabric2.measurements.map((m, index) => (
                  <div key={index} className="p-3 rounded-lg bg-secondary/30 text-sm space-y-1">
                    <div className="flex justify-between font-medium">
                      <span>Curtain {index + 1}</span>
                      <span>{formatCurrency(m.subtotal)}</span>
                    </div>
                    <div className="flex justify-between text-muted-foreground text-xs">
                      <span>
                        {m.height} {m.unit} → {m.fabricMeters.toFixed(2)}m × ₹{priceBreakdown.fabric2.ratePerMeter} = {formatCurrency(m.fabricCost)}
                      </span>
                      <span>× {m.quantity}</span>
                    </div>
                  </div>
                ))}
                <div className="flex justify-between text-sm pt-1">
                  <span className="text-muted-foreground">Fabric 2 Subtotal:</span>
                  <span className="font-medium">{formatCurrency(priceBreakdown.fabric2.subtotal)} ({priceBreakdown.fabric2.totalFabricMeters.toFixed(2)}m)</span>
                </div>
              </div>
            )}
            
            <div className="border-t border-border pt-3 space-y-2 text-sm">
              <div className="flex justify-between font-medium text-primary">
                <span>Total Fabric Required:</span>
                <span>{priceBreakdown.totalFabricMeters.toFixed(2)} meters</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Fabric Cost:</span>
                <span>{formatCurrency(priceBreakdown.totalFabricCost)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">
                  Stitching ({formatCurrency(priceBreakdown.stitchingChargePerCurtain)} × {priceBreakdown.totalCurtains}):
                </span>
                <span>{formatCurrency(priceBreakdown.totalStitchingCharge)}</span>
              </div>
              {priceBreakdown.totalAddonsCost > 0 && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">
                    Add-ons ({formatCurrency(priceBreakdown.addonsPerCurtain)} × {priceBreakdown.totalCurtains}):
                  </span>
                  <span>{formatCurrency(priceBreakdown.totalAddonsCost)}</span>
                </div>
              )}
            </div>

            <div className="border-t border-border pt-3">
              <div className="flex justify-between items-center">
                <div>
                  <span className="text-lg font-semibold font-serif">Grand Total</span>
                  <span className="text-sm text-muted-foreground ml-2">({priceBreakdown.totalCurtains} curtains)</span>
                </div>
                <span className="text-2xl font-bold text-primary">
                  {formatCurrency(priceBreakdown.grandTotal)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Button 
        onClick={handleGenerateQuote}
        disabled={!isValid}
        className="w-full py-6 text-lg font-semibold"
        size="lg"
      >
        Generate Quote
      </Button>
    </div>
  );
}
