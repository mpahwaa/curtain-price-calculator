import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { supabase } from '@/integrations/supabase/client';
import { formatCurrency } from '@/lib/calculations';
import { History, Search, FileDown, X, ChevronLeft } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import jsPDF from 'jspdf';

interface Quote {
  id: string;
  quote_number: string;
  created_at: string;
  total_amount: number;
  quantity: number;
  fabric_meters: number;
  status: string;
  customers: {
    name: string;
    phone: string;
    email: string | null;
  } | null;
  curtain_types: {
    name: string;
  } | null;
}

interface QuoteHistoryProps {
  onClose: () => void;
}

export default function QuoteHistory({ onClose }: QuoteHistoryProps) {
  const { toast } = useToast();
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedQuote, setSelectedQuote] = useState<Quote | null>(null);
  const [exportingId, setExportingId] = useState<string | null>(null);

  useEffect(() => {
    fetchQuotes();
  }, []);

  const fetchQuotes = async () => {
    try {
      const { data, error } = await supabase
        .from('quotes')
        .select(`
          id,
          quote_number,
          created_at,
          total_amount,
          quantity,
          fabric_meters,
          status,
          customers (name, phone, email),
          curtain_types (name)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setQuotes(data || []);
    } catch (error: any) {
      console.error('Error fetching quotes:', error);
      toast({
        title: 'Error',
        description: 'Failed to load quote history.',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const filteredQuotes = quotes.filter(quote => {
    const search = searchTerm.toLowerCase();
    return (
      quote.quote_number.toLowerCase().includes(search) ||
      quote.customers?.name?.toLowerCase().includes(search) ||
      quote.customers?.phone?.includes(search)
    );
  });

  const exportToPDF = async (quote: Quote) => {
    setExportingId(quote.id);
    
    try {
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pageWidth = pdf.internal.pageSize.getWidth();
      
      // Header
      pdf.setFontSize(20);
      pdf.setFont('helvetica', 'bold');
      pdf.text('CURTAIN QUOTE', pageWidth / 2, 20, { align: 'center' });
      
      pdf.setFontSize(12);
      pdf.setFont('helvetica', 'normal');
      pdf.text(`Quote #: ${quote.quote_number}`, pageWidth / 2, 30, { align: 'center' });
      pdf.text(`Date: ${new Date(quote.created_at || '').toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      })}`, pageWidth / 2, 36, { align: 'center' });

      // Customer Details
      let y = 50;
      pdf.setFontSize(14);
      pdf.setFont('helvetica', 'bold');
      pdf.text('Customer Details', 20, y);
      
      y += 8;
      pdf.setFontSize(11);
      pdf.setFont('helvetica', 'normal');
      pdf.text(`Name: ${quote.customers?.name || 'N/A'}`, 20, y);
      y += 6;
      pdf.text(`Phone: ${quote.customers?.phone || 'N/A'}`, 20, y);
      if (quote.customers?.email) {
        y += 6;
        pdf.text(`Email: ${quote.customers.email}`, 20, y);
      }

      // Quote Details
      y += 15;
      pdf.setFontSize(14);
      pdf.setFont('helvetica', 'bold');
      pdf.text('Quote Details', 20, y);
      
      y += 8;
      pdf.setFontSize(11);
      pdf.setFont('helvetica', 'normal');
      pdf.text(`Style: ${quote.curtain_types?.name || 'N/A'}`, 20, y);
      y += 6;
      pdf.text(`Total Curtains: ${quote.quantity}`, 20, y);
      y += 6;
      pdf.text(`Total Fabric: ${quote.fabric_meters.toFixed(2)} meters`, 20, y);

      // Total
      y += 20;
      pdf.setFillColor(245, 245, 245);
      pdf.rect(20, y - 5, pageWidth - 40, 15, 'F');
      pdf.setFontSize(14);
      pdf.setFont('helvetica', 'bold');
      pdf.text('Grand Total:', 25, y + 5);
      pdf.text(formatCurrency(quote.total_amount), pageWidth - 25, y + 5, { align: 'right' });

      // Footer
      y = pdf.internal.pageSize.getHeight() - 20;
      pdf.setFontSize(9);
      pdf.setFont('helvetica', 'normal');
      pdf.setTextColor(128, 128, 128);
      pdf.text('Thank you for your business!', pageWidth / 2, y, { align: 'center' });

      pdf.save(`Quote-${quote.quote_number}.pdf`);
      
      toast({
        title: 'PDF Exported',
        description: `Quote ${quote.quote_number} has been downloaded.`,
      });
    } catch (error) {
      console.error('Error exporting PDF:', error);
      toast({
        title: 'Error',
        description: 'Failed to export PDF.',
        variant: 'destructive',
      });
    } finally {
      setExportingId(null);
    }
  };

  if (loading) {
    return (
      <Card className="shadow-soft">
        <CardContent className="pt-6 text-center">
          <p className="text-muted-foreground">Loading quotes...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4 animate-fade-in">
      <Card className="shadow-soft">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-xl font-serif">
              <History className="h-5 w-5 text-accent" />
              Quote History
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-5 w-5" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by quote number, name, or phone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {filteredQuotes.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              {searchTerm ? 'No quotes found matching your search.' : 'No quotes generated yet.'}
            </p>
          ) : (
            <div className="space-y-3 max-h-[60vh] overflow-y-auto">
              {filteredQuotes.map((quote) => (
                <div
                  key={quote.id}
                  className="p-4 border border-border rounded-lg hover:bg-secondary/30 transition-colors"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono font-semibold text-primary">
                          {quote.quote_number}
                        </span>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${
                          quote.status === 'pending' 
                            ? 'bg-yellow-100 text-yellow-700' 
                            : 'bg-green-100 text-green-700'
                        }`}>
                          {quote.status}
                        </span>
                      </div>
                      <p className="text-sm font-medium truncate">
                        {quote.customers?.name || 'Unknown Customer'}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {quote.customers?.phone}
                      </p>
                      <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                        <span>{quote.quantity} curtains</span>
                        <span>{quote.fabric_meters.toFixed(2)}m</span>
                        <span>{new Date(quote.created_at || '').toLocaleDateString('en-IN')}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-primary">
                        {formatCurrency(quote.total_amount)}
                      </p>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => exportToPDF(quote)}
                        disabled={exportingId === quote.id}
                        className="mt-2"
                      >
                        <FileDown className="h-4 w-4 mr-1" />
                        {exportingId === quote.id ? 'Exporting...' : 'PDF'}
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Button variant="outline" onClick={onClose} className="w-full">
        <ChevronLeft className="h-4 w-4 mr-2" />
        Back to Calculator
      </Button>
    </div>
  );
}
