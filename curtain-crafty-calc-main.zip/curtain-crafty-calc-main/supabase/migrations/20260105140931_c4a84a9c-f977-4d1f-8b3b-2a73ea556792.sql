-- Drop existing policies on customers
DROP POLICY IF EXISTS "Admins can manage customers" ON customers;
DROP POLICY IF EXISTS "Anyone can create customers" ON customers;

-- Allow anyone to insert customers (PERMISSIVE for quote generation)
CREATE POLICY "Anyone can create customers" ON customers
FOR INSERT TO anon, authenticated
WITH CHECK (true);

-- Only admins can view customers
CREATE POLICY "Admins can view customers" ON customers
FOR SELECT USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
);

-- Only admins can update customers
CREATE POLICY "Admins can update customers" ON customers
FOR UPDATE USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
);

-- Only admins can delete customers
CREATE POLICY "Admins can delete customers" ON customers
FOR DELETE USING (
  EXISTS (SELECT 1 FROM profiles WHERE profiles.id = auth.uid() AND profiles.is_admin = true)
);