-- Allow anyone to insert quotes (for quote generation)
DROP POLICY IF EXISTS "Anyone can create quotes" ON public.quotes;
CREATE POLICY "Anyone can create quotes" ON public.quotes
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Allow anyone to view quotes (for history)
DROP POLICY IF EXISTS "Anyone can view quotes" ON public.quotes;
CREATE POLICY "Anyone can view quotes" ON public.quotes
  FOR SELECT
  TO anon, authenticated
  USING (true);