-- Fix the customers INSERT policy - make it PERMISSIVE so anyone can create customers
DROP POLICY IF EXISTS "Anyone can create customers" ON public.customers;

CREATE POLICY "Anyone can create customers"
ON public.customers
FOR INSERT
TO anon, authenticated
WITH CHECK (true);