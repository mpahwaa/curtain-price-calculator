-- Create enum for measurement units
CREATE TYPE public.measurement_unit AS ENUM ('inches', 'feet', 'meters');

-- Create fabrics table
CREATE TABLE public.fabrics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    rate_per_sqft DECIMAL(10, 2) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create curtain types table
CREATE TABLE public.curtain_types (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    fabric_multiplier DECIMAL(4, 2) NOT NULL DEFAULT 1.0,
    stitching_charge DECIMAL(10, 2) NOT NULL DEFAULT 0,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create addons table
CREATE TABLE public.addons (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create customers table
CREATE TABLE public.customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    phone TEXT,
    email TEXT,
    address TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create quotes table
CREATE TABLE public.quotes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    quote_number TEXT NOT NULL UNIQUE,
    customer_id UUID REFERENCES public.customers(id) ON DELETE SET NULL,
    width DECIMAL(10, 2) NOT NULL,
    height DECIMAL(10, 2) NOT NULL,
    unit measurement_unit NOT NULL DEFAULT 'feet',
    fabric_id UUID REFERENCES public.fabrics(id) ON DELETE SET NULL,
    curtain_type_id UUID REFERENCES public.curtain_types(id) ON DELETE SET NULL,
    quantity INTEGER NOT NULL DEFAULT 1,
    fabric_area DECIMAL(10, 2) NOT NULL,
    fabric_cost DECIMAL(10, 2) NOT NULL,
    stitching_cost DECIMAL(10, 2) NOT NULL,
    addons_cost DECIMAL(10, 2) NOT NULL DEFAULT 0,
    total_amount DECIMAL(10, 2) NOT NULL,
    selected_addons JSONB DEFAULT '[]',
    notes TEXT,
    status TEXT DEFAULT 'pending',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create admin profiles table
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT,
    full_name TEXT,
    is_admin BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.fabrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.curtain_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.addons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quotes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Fabrics: Public read, admin write
CREATE POLICY "Anyone can view active fabrics" ON public.fabrics
    FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage fabrics" ON public.fabrics
    FOR ALL TO authenticated
    USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));

-- Curtain Types: Public read, admin write
CREATE POLICY "Anyone can view active curtain types" ON public.curtain_types
    FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage curtain types" ON public.curtain_types
    FOR ALL TO authenticated
    USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));

-- Addons: Public read, admin write
CREATE POLICY "Anyone can view active addons" ON public.addons
    FOR SELECT USING (is_active = true);

CREATE POLICY "Admins can manage addons" ON public.addons
    FOR ALL TO authenticated
    USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));

-- Customers: Admin only
CREATE POLICY "Admins can manage customers" ON public.customers
    FOR ALL TO authenticated
    USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));

-- Allow insert for anonymous quote generation
CREATE POLICY "Anyone can create customers" ON public.customers
    FOR INSERT WITH CHECK (true);

-- Quotes: Admin read all, public can create
CREATE POLICY "Admins can manage quotes" ON public.quotes
    FOR ALL TO authenticated
    USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_admin = true));

CREATE POLICY "Anyone can create quotes" ON public.quotes
    FOR INSERT WITH CHECK (true);

-- Profiles: Users can read their own
CREATE POLICY "Users can view own profile" ON public.profiles
    FOR SELECT TO authenticated
    USING (id = auth.uid());

CREATE POLICY "Users can update own profile" ON public.profiles
    FOR UPDATE TO authenticated
    USING (id = auth.uid());

-- Create trigger for new user profile
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
    INSERT INTO public.profiles (id, email, full_name, is_admin)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data ->> 'full_name', NEW.email),
        false
    );
    RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add updated_at triggers to all tables
CREATE TRIGGER update_fabrics_updated_at BEFORE UPDATE ON public.fabrics FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_curtain_types_updated_at BEFORE UPDATE ON public.curtain_types FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_addons_updated_at BEFORE UPDATE ON public.addons FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_customers_updated_at BEFORE UPDATE ON public.customers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_quotes_updated_at BEFORE UPDATE ON public.quotes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default data
INSERT INTO public.fabrics (name, rate_per_sqft, description) VALUES
    ('Cotton', 25.00, 'Breathable and lightweight cotton fabric'),
    ('Silk', 75.00, 'Luxurious and elegant silk fabric'),
    ('Velvet', 65.00, 'Rich and heavy velvet fabric'),
    ('Linen', 35.00, 'Natural and textured linen fabric'),
    ('Polyester', 20.00, 'Durable and affordable polyester fabric');

INSERT INTO public.curtain_types (name, fabric_multiplier, stitching_charge, description) VALUES
    ('Eyelets (Grommets)', 2.0, 150.00, 'Modern style with metal rings'),
    ('Pleated (Pinch/Box)', 2.5, 200.00, 'Classic pleated style for elegant look'),
    ('Tab Top / Loop', 1.8, 120.00, 'Casual style with fabric loops'),
    ('Rod Pocket / Casing', 1.5, 100.00, 'Traditional style with rod sleeve');

INSERT INTO public.addons (name, price, description) VALUES
    ('Blackout Lining', 50.00, 'Blocks sunlight completely'),
    ('Thermal Lining', 40.00, 'Helps with insulation'),
    ('Curtain Hooks (Set)', 15.00, 'Metal hooks for hanging'),
    ('Tiebacks (Pair)', 25.00, 'Decorative tiebacks'),
    ('Installation Service', 200.00, 'Professional installation');