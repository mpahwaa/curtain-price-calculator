-- Rename rate_per_sqft to rate_per_meter in fabrics table
ALTER TABLE public.fabrics RENAME COLUMN rate_per_sqft TO rate_per_meter;

-- Remove fabric_multiplier from curtain_types table (stitching charge stays)
ALTER TABLE public.curtain_types DROP COLUMN fabric_multiplier;

-- Update quotes table to store fabric_meters instead of fabric_area
ALTER TABLE public.quotes RENAME COLUMN fabric_area TO fabric_meters;